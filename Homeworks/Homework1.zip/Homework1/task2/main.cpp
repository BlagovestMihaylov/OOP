#include <iostream>
#include "Film.h"

int main()
{

    Film film1;
    film1.setAwards(7);
    film1.setDirectorName("Stefan Gergzhikov");
    film1.setName("Horror in FMI");
    film1.Print();
}